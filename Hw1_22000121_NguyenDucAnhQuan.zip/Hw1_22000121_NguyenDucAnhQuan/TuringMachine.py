class TuringMachine:
    def __init__(self, initial_tape):
        self.tape = ['S'] + list(initial_tape) + ['S']
        self.head = 1
        self.state = "q0"

    def run(self):
        while self.state != "halt":
            current_symbol = self.tape[self.head]
            self.step(current_symbol)
        
        result = ''.join(self.tape).replace("S", "").strip()
        print(f"Result: {result}")
    
    def step(self, current_symbol):
        pass

    def move_left(self):
        self.head -= 1
        if self.head < 0:
            self.tape.insert(0, 'S')
            self.head = 0

    def move_right(self):
        self.head += 1
        if self.head >= len(self.tape):
            self.tape.append('S')
    
    def write(self, new_symbol):
        self.tape[self.head] = new_symbol


class TuringMachineM1(TuringMachine):
    def step(self, current_symbol):
        if self.state == "q0":
            if current_symbol in ['0', '1']:
                self.move_right()
            elif current_symbol == 'S':
                self.state = "q1"
                self.move_left()
        elif self.state == "q1":
            if current_symbol == '1':
                self.write('0')
                self.move_left()
            elif current_symbol == '0':
                self.write('1')
                self.state = "halt"
            elif current_symbol == 'S':
                self.write('1')
                self.state = "halt"


class TuringMachineM3(TuringMachine):
    def step(self, current_symbol):
        if self.state == "q0":
            if current_symbol == '0':
                self.write('1')
                self.move_right()
            elif current_symbol == '1':
                self.write('0')
                self.move_right()
            elif current_symbol == 'S':
                self.state = "halt"


class TuringMachineM6(TuringMachine):
    def step(self, current_symbol):
        if self.state == "q0":
            self.move_left()
            self.state = "q1"
        elif self.state == "q1":
            self.write('S')
            self.state = "halt"


if __name__ == "__main__":
    m1 = TuringMachineM1("1011")
    m1.run()
    
    m11 = TuringMachineM1("11")
    m11.run()
    
    m3 = TuringMachineM3("101010")
    m3.run()
    
    m6 = TuringMachineM6("10101")
    m6.run()
